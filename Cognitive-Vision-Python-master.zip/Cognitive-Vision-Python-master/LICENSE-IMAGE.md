Copyright (c) Microsoft Corporation

All rights reserved.

Microsoft Cognitive Services Client SDK License for Sample Image

*This license applies only to the sample images. The SDK code is licensed separately, please refer to [LICENSE](</LICENSE.md>)*

Microsoft may make sample images available in connection with the SDK for the purposes of illustrating the operation of Microsoft Cognitive Services (https://www.microsoft.com/cognitive-services). If no separate license terms are provided with the images, Microsoft grants you a personal, nonexclusive, revocable, royalty-free right to use the images solely within your organization to test the operation of Microsoft Cognitive Services, provided that you agree to indemnify, hold harmless, and defend Microsoft and its suppliers from and against any claims or lawsuits, including attorneys’ fees, that arise or result from the use or distribution of the images. Except as expressly provided in this section you have no license to modify or distribute the images.
